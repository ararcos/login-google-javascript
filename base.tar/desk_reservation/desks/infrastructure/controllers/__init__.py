from .create_desk import create_desk_controller
from .delete_desk import delete_desk_controller
from .get_desk import get_desk_controller
from .update_desk import update_desk_controller
from .find_desks import find_desks_controller

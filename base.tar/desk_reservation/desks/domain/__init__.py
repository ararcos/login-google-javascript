from .entities.desk import Desk
from .repositories.desk_repository import DeskRepository

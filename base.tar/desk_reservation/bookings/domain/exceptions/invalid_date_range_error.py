from ....shared.domain.exceptions import DomainError


class InvalidDateRange(DomainError):
    pass

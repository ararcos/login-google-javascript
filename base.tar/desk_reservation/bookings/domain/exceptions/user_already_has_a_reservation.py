from ....shared.domain.exceptions import DomainError


class UserAlreadyHasReservation(DomainError):
    pass

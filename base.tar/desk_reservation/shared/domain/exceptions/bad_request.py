from .domain_error import DomainError


class BadRequestError(DomainError):
    pass

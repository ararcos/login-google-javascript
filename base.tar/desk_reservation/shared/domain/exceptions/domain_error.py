class DomainError(Exception):
    pass

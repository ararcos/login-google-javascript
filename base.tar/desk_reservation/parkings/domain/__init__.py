from .entities.parking import Parking
from .repositories.parking_repository import ParkingRepository
